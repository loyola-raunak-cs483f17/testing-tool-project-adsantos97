package com;

public class DemoClass {
	public String sum(int a, int b) {
		return String.valueOf(a+b);
	}
}
